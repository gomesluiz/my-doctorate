
public class ItemEscolhido {

}
