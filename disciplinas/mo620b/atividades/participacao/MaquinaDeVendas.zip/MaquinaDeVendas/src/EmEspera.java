
public class EmEspera extends EstadoDaMaquina {

	@Override
	public void escolherProduto(MaquinaDeVendas maquinaDeVendas, ItemEscolhido item) {
		if (!temEmEstoque(item)) {
			maquinaDeVendas.mudarPara(MaquinaDeVendas.COM_PRODUTO_INSUFICIENTE);
		}
		maquinaDeVendas.mudarPara(MaquinaDeVendas.COM_PRODUTO_ESCOLHIDO);
		notificar("O produto foi selecionado");
	}

	@Override
	public void inserirDinheiro(MaquinaDeVendas maquinaDeVendas, double quantia) {
		notificar("O produto ainda não foi selecionado");

	}

	private boolean temEmEstoque(ItemEscolhido item) {
		return true;
	}

	@Override
	public void liberarTroco(MaquinaDeVendas maquinaDeVendas, double quantia) {
		notificar("Nem o produto foi selecionado nem o dinheiro foi recolhido");

	}

	@Override
	public void liberarProduto(MaquinaDeVendas maquinaDeVendas) {
		notificar("Nem o produto foi selecionado nem o dinheiro foi recolhido");

	}

}
