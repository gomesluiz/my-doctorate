
public class MaquinaDeVendas {

	static final EstadoDaMaquina EM_ESPERA = new EmEspera();
	static final EstadoDaMaquina COM_PRODUTO_ESCOLHIDO = new ComProdutoEscolhido();
	static final EstadoDaMaquina COM_DINHEIRO_RECOLHIDO = new ComDinheiroRecolhido();
	static final EstadoDaMaquina COM_PRODUTO_INSUFICIENTE = new ComProdutoInsuficiente();
	static final EstadoDaMaquina COM_DINHEIRO_INSUFICIENTE = new ComDinheiroInsuficiente();
	static final EstadoDaMaquina COM_TROCO_INSUFICIENTE = new ComTrocoInsuficiente();

	private EstadoDaMaquina estadoCorrente;

	public MaquinaDeVendas() {
		estadoCorrente = EM_ESPERA;
	}

	public void escolherProduto(ItemEscolhido item) {
		estadoCorrente.escolherProduto(this, item);

	}

	public void inserirDinheiro(double quantia) {
		estadoCorrente.inserirDinheiro(this, quantia);
	}

	public void cancelarOperacao() {
		estadoCorrente.cancelar(this);
	}

	public void devolverDinheiro(){
		estadoCorrente.devolverDinheiro(null);
		
	}
	
	public void liberarProduto() {
		estadoCorrente.liberarProduto(this);
	}
	
	

	protected void liberarProduto(Produto produto){
		
	}
	
	protected void devolverDinheiro(double quantia) {
		
	}
	
	protected void mudarPara(EstadoDaMaquina proximo) {
		estadoCorrente = proximo;
	}

}
