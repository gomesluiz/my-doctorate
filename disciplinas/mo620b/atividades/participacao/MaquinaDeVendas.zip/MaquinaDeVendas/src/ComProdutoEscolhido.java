
public class ComProdutoEscolhido extends EstadoDaMaquina {

	@Override
	public void escolherProduto(MaquinaDeVendas maquinaDeVendas, ItemEscolhido item) {
		notificar("O produto já foi escolhido !");

	}

	@Override
	public void inserirDinheiro(MaquinaDeVendas maquinaDeVendas, double quantia) {
		
		if (!aQuantiaEhSuficiente(quantia))		
			maquinaDeVendas.mudarPara(MaquinaDeVendas.COM_DINHEIRO_INSUFICIENTE);
		
		maquinaDeVendas.mudarPara(MaquinaDeVendas.COM_DINHEIRO_RECOLHIDO);
	}

	private boolean aQuantiaEhSuficiente(double quantia) {
		return true;
	}

	@Override
	public void liberarTroco(MaquinaDeVendas maquinaDeVendas, double quantia) {
		notificar("O dinheiro ainda não foi inserido");
		
	}

	@Override
	public void liberarProduto(MaquinaDeVendas maquinaDeVendas) {
		notificar("O dinheiro ainda não foi inserido");
		
	}

	
	
}
