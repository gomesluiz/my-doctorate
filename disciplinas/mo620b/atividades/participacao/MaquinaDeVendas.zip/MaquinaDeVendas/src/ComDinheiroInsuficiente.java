
public class ComDinheiroInsuficiente extends EstadoDaMaquina {

	@Override
	public void escolherProduto(MaquinaDeVendas maquinaDeVendas, ItemEscolhido produto) {

	}

	@Override
	public void inserirDinheiro(MaquinaDeVendas maquinaDeVendas, double quantia) {

	}

	@Override
	public void liberarTroco(MaquinaDeVendas maquinaDeVendas, double quantia) {

	}

	@Override
	public void liberarProduto(MaquinaDeVendas maquinaDeVendas) {
		notificar("O dinheiro é insuficiente !");

	}

}
