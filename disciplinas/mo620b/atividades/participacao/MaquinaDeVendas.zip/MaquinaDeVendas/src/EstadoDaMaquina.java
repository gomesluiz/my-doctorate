public abstract class EstadoDaMaquina {
	public abstract void escolherProduto(MaquinaDeVendas maquinaDeVendas, ItemEscolhido produto);

	public abstract void inserirDinheiro(MaquinaDeVendas maquinaDeVendas, double quantia);

	public abstract void liberarTroco(MaquinaDeVendas maquinaDeVendas, double quantia);

	public abstract void liberarProduto(MaquinaDeVendas maquinaDeVendas);

	public void cancelar(MaquinaDeVendas maquinaDeVendas) {
		maquinaDeVendas.mudarPara(MaquinaDeVendas.EM_ESPERA);
	}

	protected void notificar(String mensagem) {
		System.out.println(mensagem);
	}

	public void devolverDinheiro(MaquinaDeVendas maquinaDeEstado) {
		// TODO Auto-generated method stub
		
	}

}
