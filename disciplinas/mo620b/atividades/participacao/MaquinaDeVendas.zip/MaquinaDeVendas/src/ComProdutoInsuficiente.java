
public class ComProdutoInsuficiente extends EstadoDaMaquina {

	@Override
	public void escolherProduto(MaquinaDeVendas maquinaDeVendas, ItemEscolhido produto) {
		// TODO Auto-generated method stub

	}

	@Override
	public void inserirDinheiro(MaquinaDeVendas maquinaDeVendas, double quantia) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void liberarTroco(MaquinaDeVendas maquinaDeVendas, double quantia) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void liberarProduto(MaquinaDeVendas maquinaDeVendas) {
		notificar("O produto é insuficiente !");
		
	}

}
